^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ur5_e_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.2.7 (2019-11-23)
------------------
* Fix loading e-series robot_description param (`#467 <https://github.com/ros-industrial/universal_robot/issues/467>`_)
* Contributors: Gonzalo Casas

1.2.6 (2019-11-19)
------------------
* Migrated all package.xml files to format=2 (`#439 <https://github.com/ros-industrial/universal_robot/issues/439>`_)
* Contributors: Felix Mauch

1.2.5 (2019-04-05)
------------------
* First release (of this package)
* Update maintainer listing: add Miguel (`#410 <https://github.com/ros-industrial/universal_robot/issues/410>`_)
* UR-E Series (`#380 <https://github.com/ros-industrial/universal_robot/issues/380>`_)
* Contributors: Dave Niewinski, gavanderhoorn
